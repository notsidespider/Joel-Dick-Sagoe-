package com.example.coursedashboardapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
